"""
Utility functions for Cabfare project
"""

__version__ = "0.1.0"

